# Integrating the MVP into Gridiron

The core optimizer is deliberately independent from Streamlit. Gridiron's existing UI/backend can call `service.solve_text()` or invoke the lower-level parser and optimizer classes directly.

## Suggested production flow

1. Gridiron user types a request into an **Ask Gridiron** box.
2. The LLM converts it into a strict `Intent` object.
3. Gridiron's database adapter supplies:
   - teams/conference membership,
   - current non-conference games,
   - true weekly availability,
   - which games are moveable/locked,
   - open FCS buy-game needs,
   - A4 scheduling needs.
4. The deterministic optimizer searches legal move chains.
5. Gridiron renders 3–5 ranked solutions with the move chain and parity impact.

## Production replacement points

### Replace `ScheduleStore.from_folder()`
Create a Gridiron-backed store that implements the same methods but reads from Dave Brown's existing database/API instead of CSV files.

### Keep `Intent`
This becomes the stable contract between the chat layer and optimizer. New scheduling objectives can be added without redesigning the UI.

### Replace recursive search at scale
The MVP uses inspectable recursive search. A national dataset should eventually use a constraint solver such as CP-SAT while retaining the same public `solve(intent)` interface.

## What the LLM should never decide

- whether a team is actually available;
- whether a game is moveable;
- whether a proposed matchup creates an FBS conference parity problem;
- whether a solution is feasible.

Those remain deterministic database/optimizer decisions.

## Intentionally out of scope

- contract amendments;
- legal drafting;
- automated negotiation;
- automatically committing a schedule change.

The MVP recommends scheduling solutions. Humans remain responsible for communication and execution.
