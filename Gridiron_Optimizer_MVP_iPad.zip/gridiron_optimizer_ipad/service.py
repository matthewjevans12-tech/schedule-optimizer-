"""Framework-neutral integration layer for embedding the MVP in Gridiron."""
from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict

from llm_parser import parse_intent
from optimizer import NonConferenceOptimizer
from store import ScheduleStore


def solve_text(prompt: str, store: ScheduleStore, default_season: int | None = None) -> Dict[str, Any]:
    intent, parser = parse_intent(prompt, store.teams.keys())
    if intent.season is None:
        intent.season = default_season

    optimizer = NonConferenceOptimizer(store)
    solutions = optimizer.solve(intent)
    return {
        "parser": parser,
        "intent": asdict(intent),
        "solutions": [asdict(solution) for solution in solutions],
    }
