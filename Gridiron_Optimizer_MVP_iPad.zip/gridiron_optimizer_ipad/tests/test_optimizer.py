from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from models import Intent
from optimizer import NonConferenceOptimizer
from store import ScheduleStore


def test_georgia_mcneese_move_finds_solution():
    store = ScheduleStore.from_folder(ROOT / "sample_data")
    opt = NonConferenceOptimizer(store)
    intent = Intent(
        action="MOVE_GAME",
        season=2027,
        target_week=2,
        conference="SEC",
        team_a="Georgia",
        team_b="McNeese",
        max_additional_moves=4,
        summary="Move Georgia-McNeese to Week 2",
    )
    sols = opt.solve(intent)
    assert sols, "Expected at least one feasible solution"
    best = sols[0]
    assert any(m.game_id == "g1" and m.to_week == 2 for m in best.moves)
    assert any(m.game_id == "g2" and m.from_week == 2 for m in best.moves)


def test_sec_week2_becomes_even_in_best_solution():
    store = ScheduleStore.from_folder(ROOT / "sample_data")
    opt = NonConferenceOptimizer(store)
    intent = Intent(
        action="MOVE_GAME",
        season=2027,
        target_week=2,
        conference="SEC",
        team_a="Georgia",
        team_b="McNeese",
        max_additional_moves=4,
    )
    sol = opt.solve(intent)[0]
    assert sol.parity_after["SEC W2"].startswith("EVEN")


def test_buy_game_matching():
    store = ScheduleStore.from_folder(ROOT / "sample_data")
    opt = NonConferenceOptimizer(store)
    intent = Intent(action="FIND_BUY_GAME", season=2027, target_week=2, team_a="Georgia", max_guarantee=600000)
    sols = opt.solve(intent)
    assert any("UT Martin" in s.title or "Northern Alabama" in s.title for s in sols)


def test_scores_prefer_fewer_moves():
    store = ScheduleStore.from_folder(ROOT / "sample_data")
    opt = NonConferenceOptimizer(store)
    sols = opt.solve(Intent(action="MOVE_GAME", season=2027, target_week=2, conference="SEC", team_a="Georgia", team_b="McNeese"))
    assert len(sols) >= 2
    assert len(sols[0].moves) <= len(sols[1].moves)
    assert sols[0].score >= sols[1].score
