# MVP Product Design

## Core product sentence

**Tell Gridiron what you are trying to accomplish; Gridiron finds the least-disruptive non-conference scheduling solution.**

## Guardrail

The LLM is never the optimizer.

Flow:

`User chat -> structured scheduling intent -> deterministic schedule graph -> ranked feasible solutions -> explanation`

This prevents a conversational model from claiming a school is open when the database says it is not.

## MVP objective function

A solution is preferred when it:

1. satisfies the user's requested move or matching need;
2. does not introduce additional FBS conference parity problems;
3. uses fewer additional game moves;
4. keeps moved games closer to their original week.

Production weighting can become configurable by conference/customer.

## Core entities for Gridiron integration

- Team
- Conference
- Non-conference Game
- Weekly Slot / Availability
- Need / Marketplace Intent
- Proposed Move
- Solution

## Future solver upgrade

The current recursive search is intentionally easy to inspect for an MVP. At national scale, replace the internal search with CP-SAT / mixed-integer optimization while preserving the same `Intent` and `Solution` interfaces.
