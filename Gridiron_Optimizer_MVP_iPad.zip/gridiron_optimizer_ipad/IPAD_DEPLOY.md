# Deploy Gridiron Optimizer from an iPad

Recommended architecture: iPad Safari -> GitHub -> Streamlit Community Cloud.
The app runs in the cloud; your iPad is the browser/client.

## 1. Save the ZIP
Download the deployment ZIP into the iPad Files app.

## 2. Create a private GitHub repository
Create a new private repository named `gridiron-optimizer-mvp` and initialize it with a README.

## 3. Upload this ZIP to the repository
On the repository page choose Add file -> Upload files, select the ZIP from Files, and commit it.

## 4. Open a GitHub Codespace
In the repository choose Code -> Codespaces -> Create codespace on main.
Open the terminal and run:

```bash
unzip Gridiron_Optimizer_MVP_iPad.zip
cp -R gridiron_optimizer_ipad/. .
rm -rf gridiron_optimizer_ipad Gridiron_Optimizer_MVP_iPad.zip
git add .
git commit -m "Deploy Gridiron optimizer MVP"
git push
```

If the ZIP has a different filename, substitute that name in the commands.

## 5. Deploy to Streamlit Community Cloud
Sign into Streamlit Community Cloud with GitHub. Create an app from your existing repository.
Use:
- Repository: `gridiron-optimizer-mvp`
- Branch: `main`
- Main file path: `app.py`
- Python: 3.12

## 6. Add OpenAI credentials
In Streamlit Advanced settings -> Secrets, add:

```toml
OPENAI_API_KEY = "your-api-key"
OPENAI_MODEL = "gpt-5.6"
```

Never put the API key in GitHub or in a committed file.

The app will run without an API key using its offline parser, but the API key enables the LLM intent parser.

## 7. Keep the app private
Use Streamlit App settings -> Sharing -> Only specific people can view this app.

## 8. Test the MVP
Paste this into Ask Gridiron:

> In 2027 the SEC is odd in Week 2. Move Georgia vs McNeese to Week 2 and figure out where to put Tarleton without creating a new FBS parity problem.

The demo should return ranked feasible solutions and show parity impact.

## 9. Put it on the iPad Home Screen
Open the deployed Streamlit URL in Safari, tap Share, then Add to Home Screen.
