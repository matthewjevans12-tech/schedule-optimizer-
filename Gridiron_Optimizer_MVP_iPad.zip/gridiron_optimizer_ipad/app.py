from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import streamlit as st

from llm_parser import parse_intent
from models import Intent
from optimizer import NonConferenceOptimizer
from store import ScheduleStore


ROOT = Path(__file__).parent
DATA = ROOT / "sample_data"

st.set_page_config(page_title="Gridiron Optimizer MVP", page_icon="🏈", layout="wide")


@st.cache_resource
def load_store() -> ScheduleStore:
    return ScheduleStore.from_folder(DATA)


store = load_store()
optimizer = NonConferenceOptimizer(store)

st.title("🏈 Gridiron Optimizer — MVP")
st.caption("Chat-first non-conference scheduling. The LLM interprets intent; the deterministic engine validates and solves.")

with st.sidebar:
    st.subheader("MVP scope")
    st.markdown("""
- Move a non-conference game and solve displaced games
- Protect FBS conference weekly parity
- Find FCS buy-game matches
- Find A4-vs-A4 matches
- No contract amendment generation
    """)
    st.divider()
    season = st.selectbox("Active season", sorted({g.season for g in store.games.values()}), index=0)
    st.caption("Demo data is synthetic and designed around the Georgia–McNeese–Tarleton use case.")


def parity_table(season: int) -> pd.DataFrame:
    rows = []
    for week in range(0, 15):
        parity = optimizer.conference_parity(store.copy_games(), season, week)
        for conference, value in parity.items():
            rows.append({"Week": week, "Conference": conference, "Status": value})
    return pd.DataFrame(rows)


def render_solution(sol, idx: int):
    label = f"#{idx} — {sol.title} · Score {sol.score:.1f}"
    with st.expander(label, expanded=(idx == 1)):
        st.write(sol.explanation)
        if sol.moves:
            df = pd.DataFrame([{
                "Game": f"{m.away_team} @ {m.home_team}",
                "From": f"Week {m.from_week}",
                "To": f"Week {m.to_week}",
            } for m in sol.moves])
            st.dataframe(df, use_container_width=True, hide_index=True)
        if sol.warnings:
            for warning in sol.warnings:
                st.warning(warning)
        if sol.parity_after:
            changed = []
            keys = sorted(set(sol.parity_before) | set(sol.parity_after))
            for key in keys:
                before = sol.parity_before.get(key, "—")
                after = sol.parity_after.get(key, "—")
                if before != after:
                    changed.append({"Conference / Week": key, "Before": before, "After": after})
            if changed:
                st.markdown("**Parity impact**")
                st.dataframe(pd.DataFrame(changed), use_container_width=True, hide_index=True)


tab_chat, tab_health, tab_schedule, tab_needs = st.tabs(["Ask Gridiron", "Conference Parity", "Schedule Data", "Open Needs"])

with tab_chat:
    st.markdown("### What are you trying to accomplish?")
    st.caption("Try: “In 2027 the SEC is odd in Week 2. Move Georgia vs McNeese to Week 2 and figure out where to put Tarleton without creating a new FBS parity problem.”")

    if "messages" not in st.session_state:
        st.session_state.messages = []

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    prompt = st.chat_input("Describe the scheduling problem...")
    if prompt:
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        intent, parser_name = parse_intent(prompt, store.teams.keys())
        # The selected season is a UI default only when the user omitted the year.
        if intent.season is None:
            intent.season = season

        with st.chat_message("assistant"):
            st.caption(f"Intent parser: {parser_name}")
            with st.expander("Interpreted scheduling request"):
                st.json(intent.__dict__)

            solutions = optimizer.solve(intent)
            if not solutions:
                st.error("I couldn't find a feasible solution in the current scheduling data. Check that the named game exists and that both schools have explicit OPEN/FLEX slots for candidate weeks.")
            else:
                if intent.action == "MOVE_GAME":
                    st.success(f"Found {len(solutions)} feasible solution{'s' if len(solutions) != 1 else ''}. Ranked by fewest moves, travel in week-space, and FBS parity impact.")
                else:
                    st.success(f"Found {len(solutions)} match/solution{'s' if len(solutions) != 1 else ''}.")
                for i, sol in enumerate(solutions, start=1):
                    render_solution(sol, i)

with tab_health:
    st.markdown("### FBS conference parity by week")
    df = parity_table(season)
    pivot = df.pivot(index="Conference", columns="Week", values="Status")
    st.dataframe(pivot, use_container_width=True)
    st.caption("Parity asks: after teams committed to non-conference games are removed, does each FBS conference have an even number of teams still available for conference play?")

with tab_schedule:
    st.markdown("### Non-conference games")
    games_df = pd.DataFrame([g.__dict__ for g in store.games.values()])
    st.dataframe(games_df.sort_values(["season", "week", "home_team"]), use_container_width=True, hide_index=True)
    st.markdown("### Explicit date availability")
    slots_df = pd.DataFrame([s.__dict__ for s in store.slots.values()])
    st.dataframe(slots_df[slots_df["season"] == season].sort_values(["team", "week"]), use_container_width=True, hide_index=True)

with tab_needs:
    st.markdown("### Marketplace / scheduling needs")
    needs_df = pd.DataFrame([n.__dict__ for n in store.needs])
    if len(needs_df):
        st.dataframe(needs_df[needs_df["season"] == season], use_container_width=True, hide_index=True)
    else:
        st.info("No needs loaded.")
