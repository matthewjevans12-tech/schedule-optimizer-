# Gridiron Optimizer MVP

A chat-first MVP for **college football non-conference scheduling**.

The architecture intentionally separates two jobs:

1. **LLM = intent parser.** The user types what they are trying to accomplish in normal language.
2. **Deterministic optimizer = source of truth.** Availability, game movement, cascading conflicts, and FBS conference parity are calculated from structured scheduling data.

The LLM never gets to invent a schedule.

## What this MVP does

- Move a named non-conference game to a requested week.
- Detect a displaced game and recursively find another week for it.
- Allow a short cascade of additional non-conference moves.
- Rank feasible solutions by disruption and FBS conference parity impact.
- Show FBS conference parity by week.
- Find FCS buy-game candidates based on recorded availability and guarantee needs.
- Find A4-vs-A4 candidates based on recorded needs.
- Use OpenAI Structured Outputs to turn chat into a validated scheduling intent when `OPENAI_API_KEY` is configured.
- Fall back to an offline parser so the demo runs without an API key.

**Deliberately not included:** contract amendment generation, negotiation workflow, or legal-document automation.

## Demo use case

The sample data is built around this request:

> In 2027 the SEC is odd in Week 2. Move Georgia vs McNeese to Week 2 and figure out where to put Tarleton without creating a new FBS parity problem.

In the sample schedule:

- Georgia–McNeese is in Week 3.
- McNeese–Tarleton is in Week 2.
- Georgia is explicitly open in Week 2.
- McNeese and Tarleton have other explicit open/flex dates.
- SEC Week 2 and Week 3 are intentionally odd before the move, so the target move can improve parity in both weeks.

## Run locally

```bash
cd gridiron_optimizer_mvp
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
streamlit run app.py
```

Then open the Streamlit URL shown in your terminal (normally `http://localhost:8501`).

## Enable the LLM chat parser

Set an API key:

```bash
export OPENAI_API_KEY="..."
export OPENAI_MODEL="gpt-5.2"   # optional; configurable
streamlit run app.py
```

The code uses the OpenAI **Responses API** with **Structured Outputs** (`json_schema`) so a free-form request is converted into the exact `Intent` shape required by the optimizer.

If the API key is absent or the model call fails, the app automatically uses a small local parser.

## Data model

### `teams.csv`

- `name`
- `subdivision` (`FBS` / `FCS`)
- `conference`
- `is_a4`
- `parity_managed` — use `true` for conferences whose complete membership is loaded; the demo tracks SEC parity only

### `games.csv`

- `game_id`
- `season`
- `week`
- `home_team`
- `away_team`
- `moveable`
- `locked`
- `notes`

### `slots.csv`

This is critical. An empty spot on a public schedule does **not** mean a school is available for non-conference play. Gridiron should own explicit availability data.

- `team`
- `season`
- `week`
- `status`: `OPEN`, `FLEX`, `BLOCKED`, `NEED_FCS`, `NEED_FBS`, `NEED_A4`
- `location`: `HOME`, `AWAY`, `ANY`

### `needs.csv`

The beginning of the scheduling marketplace / proprietary intent layer.

- `team`
- `season`
- `week`
- `need_type`: `FCS_BUY`, `FBS`, `A4`
- `location`
- `min_guarantee`
- `max_guarantee`
- `notes`

## Why this architecture matters for Gridiron

The strategic moat is not the chat box. It is the private national database of:

- committed games,
- true open dates,
- games schools are willing to move,
- buy-game needs,
- A4 needs,
- home/away requirements,
- and conference parity consequences.

The LLM makes that data easy to query. The optimizer makes the answer reliable.

## Production roadmap

### Phase 1 — This MVP
Chat → structured intent → deterministic solution.

### Phase 2 — Real Gridiron data
Replace CSVs with Gridiron's database/API and permissions.

### Phase 3 — Better optimization
Move the search engine to a constraint solver (for example OR-Tools CP-SAT) for national-scale, multi-year problems and weighted objectives.

### Phase 4 — Marketplace intelligence
Allow schools/conferences to maintain private `Needs` and `Moveable` status. Add matching, saved searches, and notifications.

### Phase 5 — National optimization
Requests such as:

> Make every FBS conference schedulable in Weeks 2–4 while preserving existing A4 games and moving the fewest non-conference games possible.

That is the end-state optimizer layer for Gridiron.
