from __future__ import annotations

import csv
from dataclasses import replace
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

from models import Game, Need, Slot, Team


class ScheduleStore:
    def __init__(self, teams: List[Team], games: List[Game], slots: List[Slot], needs: List[Need]):
        self.teams = {t.name: t for t in teams}
        self.games = {g.game_id: g for g in games}
        self.slots = {(s.team, s.season, s.week): s for s in slots}
        self.needs = needs

    @classmethod
    def from_folder(cls, folder: str | Path) -> "ScheduleStore":
        folder = Path(folder)
        teams: List[Team] = []
        games: List[Game] = []
        slots: List[Slot] = []
        needs: List[Need] = []

        with (folder / "teams.csv").open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                teams.append(Team(
                    name=row["name"].strip(),
                    subdivision=row["subdivision"].strip().upper(),
                    conference=row["conference"].strip(),
                    is_a4=row.get("is_a4", "false").strip().lower() in {"1", "true", "yes", "y"},
                    parity_managed=row.get("parity_managed", "true").strip().lower() in {"1", "true", "yes", "y"},
                ))

        with (folder / "games.csv").open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                games.append(Game(
                    game_id=row["game_id"].strip(),
                    season=int(row["season"]),
                    week=int(row["week"]),
                    home_team=row["home_team"].strip(),
                    away_team=row["away_team"].strip(),
                    moveable=row.get("moveable", "true").strip().lower() in {"1", "true", "yes", "y"},
                    locked=row.get("locked", "false").strip().lower() in {"1", "true", "yes", "y"},
                    notes=row.get("notes", "").strip(),
                ))

        slots_path = folder / "slots.csv"
        if slots_path.exists():
            with slots_path.open(newline="", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    slots.append(Slot(
                        team=row["team"].strip(),
                        season=int(row["season"]),
                        week=int(row["week"]),
                        status=row["status"].strip().upper(),
                        location=row.get("location", "ANY").strip().upper() or "ANY",
                    ))

        needs_path = folder / "needs.csv"
        if needs_path.exists():
            with needs_path.open(newline="", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    needs.append(Need(
                        team=row["team"].strip(),
                        season=int(row["season"]),
                        week=int(row["week"]),
                        need_type=row["need_type"].strip().upper(),
                        location=row.get("location", "ANY").strip().upper() or "ANY",
                        min_guarantee=int(row["min_guarantee"]) if row.get("min_guarantee", "").strip() else None,
                        max_guarantee=int(row["max_guarantee"]) if row.get("max_guarantee", "").strip() else None,
                        notes=row.get("notes", "").strip(),
                    ))

        return cls(teams, games, slots, needs)

    def copy_games(self) -> Dict[str, Game]:
        return dict(self.games)

    def find_game(self, team_a: str, team_b: str, season: Optional[int] = None) -> Optional[Game]:
        wanted = {team_a, team_b}
        for game in self.games.values():
            if season is not None and game.season != season:
                continue
            if {game.home_team, game.away_team} == wanted:
                return game
        return None

    def game_for_team_week(self, games: Dict[str, Game], team: str, season: int, week: int, exclude_game_id: Optional[str] = None) -> Optional[Game]:
        for game in games.values():
            if game.game_id == exclude_game_id:
                continue
            if game.season == season and game.week == week and game.involves(team):
                return game
        return None

    def slot(self, team: str, season: int, week: int) -> Optional[Slot]:
        return self.slots.get((team, season, week))

    def slot_allows_game(self, team: str, season: int, week: int) -> bool:
        slot = self.slot(team, season, week)
        if slot is None:
            return False  # explicit availability is required in this MVP
        return slot.status in {"OPEN", "FLEX", "NEED_FCS", "NEED_FBS", "NEED_A4"}

    def conference_members(self, conference: str) -> List[Team]:
        return [t for t in self.teams.values() if t.subdivision == "FBS" and t.conference == conference and t.parity_managed]

    def fbs_conferences(self) -> List[str]:
        return sorted({t.conference for t in self.teams.values() if t.subdivision == "FBS" and t.conference and t.parity_managed})
