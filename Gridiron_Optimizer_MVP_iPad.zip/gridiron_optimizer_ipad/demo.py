from models import Intent
from optimizer import NonConferenceOptimizer
from store import ScheduleStore

store = ScheduleStore.from_folder("sample_data")
optimizer = NonConferenceOptimizer(store)
intent = Intent(
    action="MOVE_GAME",
    season=2027,
    target_week=2,
    conference="SEC",
    team_a="Georgia",
    team_b="McNeese",
    preserve_fbs_conference_parity=True,
    max_additional_moves=4,
)

print("Before:", optimizer.conference_parity(store.copy_games(), 2027, 2)["SEC"])
for i, solution in enumerate(optimizer.solve(intent), 1):
    print(f"\nSolution {i}: score={solution.score}")
    for move in solution.moves:
        print(f"  {move.away_team} @ {move.home_team}: Week {move.from_week} -> Week {move.to_week}")
    print("  SEC Week 2:", solution.parity_after.get("SEC W2"))
    print("  SEC Week 3:", solution.parity_after.get("SEC W3"))
