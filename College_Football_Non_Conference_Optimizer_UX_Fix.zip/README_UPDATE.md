# College Football Non-Conference Scheduling Optimizer — UX Fix

This update addresses two issues identified from iPad testing:

1. **Drag/drop interaction**
   - Calendar logos no longer trigger Safari's native image drag.
   - The schedule editor shows every dated non-conference game for the selected team on a 14-week rail.
   - Drag any game directly to a target week; no separate game selector is required.
   - Clean moves are accepted into the what-if workspace.
   - Blocked moves snap back and automatically surface the minimum-change CP-SAT repair path.
   - Move feedback now appears above the schedule editor, adjacent to the action that caused it.

2. **Unresolved parity issues**
   - An unexplained count such as “22 unresolved issues” is replaced by an inspectable issue register.
   - Each issue shows conference, week, conference teams available, non-conference teams, and the known games contributing to that week's inventory.
   - A user can select an unresolved issue and ask the optimizer for the least-disruptive next fix.

## Deploy
Replace `app.py` in GitHub. `requirements.txt` is unchanged from the prior drag/drop release.
